cf_tmle_delay <- function(task, propensity_scores, prob_observed, learners, control, progress_bar) {
  ans <- vector("list", length = length(task$folds))

  for (fold in seq_along(task$folds)) {
    ans[[fold]] <- future::future({
      estimate_tmle_delay(task, fold, propensity_scores, prob_observed, learners, control, progress_bar)
    },
    seed = TRUE)
  }

  ans <- future::value(ans)

  list(predictions = recombine(c_depth(ans, "predictions"), task$folds),
       uncentered_eif = recombine(c_depth(ans, "uncentered_eif"), task$folds),
       learner_outcome_summary = rbind_depth(ans, "learner_summary"))
}

estimate_tmle_delay <- function(task, fold, propensity_scores, prob_observed, learners, control, progress_bar) {
  data <- get_folded_data(task$natural, task$folds, fold)

  # Cache used objects to prevent look-ups
  time_horizon <- task$time_horizon
  seq_time_horizon <- task$sequences(time_horizon)

  # Augment data
  train <- data$train
  valid <- data$valid
  train_aug <- delay_augment(train, seq_time_horizon)
  valid_aug <- delay_augment(valid, seq_time_horizon)

  propensity_scores <- get_folded_data(propensity_scores, task$folds, fold)
  prob_observed <- get_folded_data(prob_observed, task$folds, fold)

  # Pre-allocate lists
  pred_train_shifted <- vector("list", time_horizon)
  pred_valid_shifted <- pred_train_shifted
  learner_summaries <- vector("list", time_horizon)

  # Pre-allocate vector for the EIF
  eif <- numeric(nrow(valid))

  # Cache used objects to prevent look-ups
  Y <- task$vars$Y
  A <- task$vars$A
  C <- task$vars$C
  id <- "..i..lmtp_id"
  cvfolds <- control$.learners_outcome_folds

  # Pre-computations
  all_sequences <- lapply(seq_len(time_horizon), task$sequences)

  # Loop backwards in time for sequential regressions
  for (time in rev(seq_len(time_horizon))) {
    y1 <- task$is_outcome_free(train, time - 1)
    d0 <- task$is_competing_risk_free(train, time - 1)
    c1 <- task$observed(train, time)
    i <- c1 %and% (y1 & d0)

    # Cache used objects to prevent look-ups
    history <- task$vars$history("L", time + 1)
    vars <- c(id, history, Y)

    # Estimate the outcome regressions
    # If its the last time point just perform this once using the real outcome
    if (time == task$time_horizon) {
      fit <- run_ensemble(train[i, vars], Y, learners, task$outcome_type, id, cvfolds)
      learner_summaries[[time]] <- summary(fit, time, fold)
    }

    # Treatment sequences we need to generate under
    sequences <- all_sequences[[time]]
    i_aug <- delay_augment(i, sequences)

    if (time < time_horizon) {
      train_aug[[Y]] <- pred_train_shifted[[time + 1]]
      valid_aug[[Y]] <- pred_valid_shifted[[time + 1]]
    }

    # Subset the augmented data
    train_aug <- subset_augmented(train_aug, time, time_horizon)
    valid_aug <- subset_augmented(valid_aug, time, time_horizon)

    if (time < time_horizon) {
      # Fit regressions for each level of support using a pooled regression
      # Add the pooling variable
      vars <- c(vars, seqvars(time))
      fit <- run_ensemble(train_aug[i_aug, vars], Y, learners, "continuous", id, cvfolds)
      learner_summaries[[time]] <- summary(fit, time, fold)
    }

    # Generate predictions
    # Get treatment at this time
    this_A <- current_trt(A, time)
    # Current censoring variable
    this_C <- C[time]

    # Create subset indicators for survival, competing risk, censoring
    cp1 <- task$observed(train, time - 1)
    y1v <- task$is_outcome_free(valid, time - 1)
    d0v <- task$is_competing_risk_free(valid, time - 1)
    cp1v <- task$observed(valid, time - 1)

    ip <- cp1 %and% (y1 & d0)
    ip_aug <- delay_augment(ip, sequences)
    y1_aug <- delay_augment(y1, sequences)
    d0_aug <- delay_augment(d0, sequences)

    iv <- cp1v %and% (y1v & d0v)
    iv_aug <- delay_augment(iv, sequences)
    y1v_aug <- delay_augment(y1v, sequences)
    d0v_aug <- delay_augment(d0v, sequences)

    # Generate predictions
    pred_train_shifted[[time]] <- predict_delay_augment(
      train_aug, fit, time, time_horizon, this_A,
      Y, ip_aug, y1_aug, d0_aug, TRUE
    )

    pred_train_natural <- predict_delay_augment(
      train_aug, fit, time, time_horizon, this_A,
      Y, ip_aug, y1_aug, d0_aug, FALSE
    )

    pred_valid_shifted[[time]] <- predict_delay_augment(
      valid_aug, fit, time, time_horizon, this_A,
      Y, iv_aug, y1v_aug, d0v_aug, TRUE
    )

    pred_valid_natural <- predict_delay_augment(
      valid_aug, fit, time, time_horizon, this_A,
      Y, iv_aug, y1v_aug, d0v_aug, FALSE
    )

    # Riesz representer
    riesz <- delay_riesz_rep(
      train_aug, A, propensity_scores$train, prob_observed$train,
      this_A, this_C, 1, time
    )

    # Fit tilting model
    fit <- fluc(train_aug[[Y]][i_aug], pred_train_natural[i_aug], riesz[i_aug])

    # Update predictions
    pred_train_shifted[[time]][i_aug] <- update(fit, pred_train_shifted[[time]][i_aug])
    pred_valid_shifted[[time]][iv_aug] <- update(fit, pred_valid_shifted[[time]][iv_aug])
    pred_valid_natural[iv_aug] <- update(fit, pred_valid_natural[iv_aug])

    # Construct the EIF
    eif <- update_htlmtp_eif(
      eif, valid_aug, A, Y, id, pred_valid_natural,
      propensity_scores$valid, prob_observed$valid, this_A, this_C, time
    )

    progress_bar()
  }

  # Time 0 component
  valid_aug[[Y]] <- pred_valid_shifted[[1]]
  valid_aug <- subset_augmented(valid_aug, 0, time_horizon)
  eif <- as.vector(eif + valid_aug[[Y]])

  list(predictions = valid_aug[[Y]],
       uncentered_eif = eif,
       learner_summary = rbindlist(learner_summaries))
}
